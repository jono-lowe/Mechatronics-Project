# Competition / hardware launch for the team 4 tracker - ONE command starts everything:
#   chasing (aims for the opponent's back/left/right), lock-on, capture + TrackerReport (with camera image),
#   5 s capture cooldown, evade after WE capture (5 s run to a random free spot),
#   counter-attack straight away if the opponent reports capturing us, and unstick when Nav2 keeps failing.
#
#   Robot:  ros2 launch tracker_team_4 tracker_two_tb4_team_4.launch.py chaser:=tb407 enemy:=tb402
#   Sim:    add  use_sim_time:=true require_image:=false cmd_vel_stamped:=false
#
# Needs localization (map -> <robot> TF) and Nav2 (/<chaser>/navigate_to_pose) running first.
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

ARGS = [
    ('chaser', None, 'REQUIRED: our robot namespace (given on the day), e.g. tb407'),
    ('enemy', None, 'REQUIRED: opponent robot namespace, e.g. tb402'),
    ('my_id', '0', 'Our id in the report (0 = from the robot name, e.g. tb407 -> 7)'),
    ('opp_id', '0', 'Opponent id in the report (0 = from the robot name)'),
    ('global_frame', 'map', 'Fixed frame used for poses and Nav2 goals'),
    ('map_topic', '/map', 'Occupancy map used to find free attack / flee spots'),
    ('use_tf_poses', 'true', 'Read both robots poses from TF (false = /<robot>/pose topics)'),
    ('camera_topic', '', "'' = /<chaser>/oakd/rgb/preview/image_raw/compressed"),
    ('require_image', 'true', 'Only capture when a camera frame has been received'),
    ('save_dir', '', "Folder to save capture JPEGs ('' = don't save)"),
    ('evade_on_capture', 'true', 'Listen to the opponent capture reports (needed for the counter-attack)'),
    ('evade_when_captured', 'false', 'false = when captured, counter-attack at once with no cooldown'),
    ('evade_after_capture', 'true', 'Run away for evade_time after WE capture the opponent'),
    ('evade_time', '5.0', 'Seconds to flee before chasing again'),
    ('capture_cooldown', '5.0', 'Minimum seconds between our captures'),
    ('capture_dist', '0.4', 'Shooting range: must be this close (m, centre to centre) for a capture'),
    ('standoff_dist', '0.5', 'Nav2 attack spot this far from the opponent (m)'),
    ('lock_dist', '0.36', 'Lock-on drives in to this distance (m), keep it below capture_dist'),
    ('capture_arc_deg', '360.0', 'Capture allowed from this arc around the opponent (360 = any angle incl. front; 220 = back/sides only)'),
    ('cmd_vel_stamped', 'true', 'TwistStamped on cmd_vel (Jazzy TurtleBot 4). false = plain Twist (Humble, this sim)'),
    ('use_sim_time', 'false', 'true only in Gazebo'),
]


def generate_launch_description():
    params = {name: LaunchConfiguration(name) for name, _, _ in ARGS}
    tracker = Node(
        package='tracker_team_4',
        executable='tracker_node',
        name='tracker_node',
        namespace=LaunchConfiguration('chaser'),
        output='screen',
        parameters=[params],
    )
    return LaunchDescription(
        [DeclareLaunchArgument(n, description=h) if d is None else
         DeclareLaunchArgument(n, default_value=d, description=h) for n, d, h in ARGS] + [tracker])
