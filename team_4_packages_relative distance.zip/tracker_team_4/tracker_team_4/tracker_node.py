import collections
import math
import random
import re
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from geometry_msgs.msg import PoseStamped, Twist, TwistStamped
from nav2_msgs.action import NavigateToPose
from tracker_msgs_team_4.msg import TrackerReport
from sensor_msgs.msg import CompressedImage
from rclpy.qos import qos_profile_sensor_data
import os
from rclpy.time import Time
from tf2_ros import Buffer, TransformListener
from nav_msgs.msg import OccupancyGrid
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy
from rclpy.duration import Duration
from rclpy.parameter import Parameter


# Attack points around the opponent - angles come from side_angle(), inside the capture arc
ATTACK_SIDES = ('back', 'left', 'right')


class TrackerNode(Node):
    def __init__(self):
        super().__init__('tracker_node')

        self.declare_parameter('chaser', '')   # OUR robot namespace - required, e.g. chaser:=tb407
        self.declare_parameter('enemy', '')    # opponent namespace - required, e.g. enemy:=tb402
        self.declare_parameter('global_frame', 'map')
        self.declare_parameter('my_id', 0)
        self.declare_parameter('opp_id', 0)
        self.declare_parameter('camera_topic', '')   # '' = /<chaser>/oakd/rgb/preview/image_raw/compressed
        self.declare_parameter('zone_max_dist', 1.5)       # lock-on starts when the opponent is this close and in view
        self.declare_parameter('capture_dist', 0.4)        # must be this close (m, centre to centre) for the shot to count
        self.declare_parameter('zone_half_fov_deg', 30.0)
        self.declare_parameter('capture_cooldown', 5.0)
        self.declare_parameter('save_dir', '')
        self.declare_parameter('standoff_dist', 0.5)       # Nav2 attack spot this far from the opponent
        self.declare_parameter('attack_clearance', 0.25)   # free space needed around an attack spot (m)
        self.declare_parameter('require_image', True)
        self.declare_parameter('use_tf_poses', False)
        self.declare_parameter('base_frame', 'base_link')   # frames are <robot>/base_link
        # Game rule: a capture only counts from the opponent's back rear_arc_deg (360 = anywhere)
        self.declare_parameter('rear_arc_deg', 220.0)      # TARGETING: aim for the back/left/right of this arc
        self.declare_parameter('capture_arc_deg', 360.0)   # CAPTURING: arc around the opponent we may capture from (360 = any angle, incl. front)
        # Attack strategy: aim for a random side (left/right/back) of the opponent, not its front
        self.declare_parameter('aim_behind', True)
        self.declare_parameter('side_reroll_time', 10.0)
        # Hold rule: opponent must stay in the capture zone this long before a capture counts
        self.declare_parameter('capture_hold_time', 0.0)   # capture counts instantly; 5 s rule is the cooldown
        self.declare_parameter('hold_grace_time', 0.5)   # drop-outs shorter than this are ignored
        # Lock-on: while holding, steer straight at the opponent with cmd_vel instead of Nav2
        self.declare_parameter('lock_on', True)
        self.declare_parameter('lock_dist', 0.36)          # lock-on drives in to this distance (< capture_dist; TB4s touch at ~0.34)
        self.declare_parameter('lock_max_lin', 0.2)
        self.declare_parameter('lock_max_ang', 1.5)
        self.declare_parameter('cmd_vel_topic', '')   # '' = /<chaser>/cmd_vel
        self.declare_parameter('cmd_vel_stamped', True)   # Jazzy TB4 uses TwistStamped
        # Evade: when the opponent captures us, run away so its cooldown can expire
        self.declare_parameter('evade_on_capture', False)
        self.declare_parameter('evade_dist', 2.0)
        self.declare_parameter('min_goal_period', 1.5)   # s between new Nav2 goals (fast preempting can crash Humble's bt_navigator)
        self.declare_parameter('goal_move_thresh', 0.4)   # only replace the goal if it moved this far (m)
        self.declare_parameter('unstick_after_fails', 2)   # Nav2 aborts in a row before we back out by ourselves
        self.declare_parameter('unstick_time', 1.5)        # s of driving (about 0.2 m)
        self.declare_parameter('evade_when_captured', False)  # False = captured robot counter-attacks instead of fleeing
        self.declare_parameter('evade_time', 5.0)   # 0 = capture_cooldown + 1.5 s
        self.declare_parameter('evade_min_opp_dist', 1.5)   # flee spot must be at least this far from the opponent
        self.declare_parameter('evade_after_capture', True)  # capturer also runs off after a capture
        self.declare_parameter('opp_report_topic', '')   # '' = /<enemy>/tracker_report
        self.declare_parameter('map_topic', '/map')
        chaser = str(self.get_parameter('chaser').value).strip('/')
        enemy = str(self.get_parameter('enemy').value).strip('/')
        if not chaser or not enemy:
            raise SystemExit('tracker_node: set both robot names, e.g.  chaser:=tb407 enemy:=tb402')
        if chaser == enemy:
            raise SystemExit('tracker_node: chaser and enemy must be different robots')
        self.set_parameters([Parameter('chaser', Parameter.Type.STRING, chaser),
                             Parameter('enemy', Parameter.Type.STRING, enemy)])
        for pname, robot in (('my_id', chaser), ('opp_id', enemy)):
            m = re.fullmatch(r'tb(\d+)(?:_(\d+))?', robot)
            if self.get_parameter(pname).value == 0 and m:
                self.set_parameters([Parameter(pname, Parameter.Type.INTEGER, (int(m.group(2)) + 1 if m.group(2) else int(m.group(1)) % 100))])
        self.get_logger().info('[START]   us: /%s (id %d)   vs   enemy: /%s (id %d)' % (
            chaser, self.get_parameter('my_id').value, enemy, self.get_parameter('opp_id').value))

        self.enemy_pose = None
        self.last_pose_time = None
        self.my_pose = None
        self.latest_image = None
        self.last_capture_time = None
        self.capture_count = 0
        self.last_goal = None
        self.last_goal_time = None

        self.create_subscription(PoseStamped, f'/{enemy}/pose', self.enemy_callback, 10)
        self.create_subscription(PoseStamped, f'/{chaser}/pose', self.my_callback, 10)
        cam_topic = self.get_parameter('camera_topic').value or f'/{chaser}/oakd/rgb/preview/image_raw/compressed'
        self.get_logger().info('[START]   camera topic:  %s' % cam_topic)
        self.create_subscription(CompressedImage, cam_topic, self.image_callback, qos_profile_sensor_data)
        self.create_timer(0.2, self.check_capture)
        if self.get_parameter('use_tf_poses').value:
            # Simulation helper: read both robots' map poses straight from TF
            # (e.g. tb3_0/base_footprint and tb3_1/base_footprint published via AMCL).
            self.tf_buffer = Buffer()
            self.tf_listener = TransformListener(self.tf_buffer, self)
            self.create_timer(0.1, self.update_poses_from_tf)
        self.report_pub = self.create_publisher(TrackerReport, f'/{chaser}/tracker_report', 10)
        self.report_img_pub = self.create_publisher(CompressedImage, f'/{chaser}/tracker_report_img/compressed', 10)
        self.nav_client = ActionClient(self, NavigateToPose, f'/{chaser}/navigate_to_pose')
        self.evade_until = None
        self.map = None
        self.attack_side = None
        self.side_time = None
        self.in_view_since = None
        self.last_in_view = None
        self.locked = False
        self.goal_handle = None
        self.cmd_pub = self.create_publisher(
            TwistStamped if self.get_parameter('cmd_vel_stamped').value else Twist,
            self.get_parameter('cmd_vel_topic').value or f'/{chaser}/cmd_vel', 10)
        self.create_timer(0.1, self.lock_control)
        if self.get_parameter('evade_on_capture').value:
            topic = self.get_parameter('opp_report_topic').value or f'/{enemy}/tracker_report'
            self.create_subscription(TrackerReport, topic, self.opp_report_callback, 10)
            map_qos = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL,
                                 reliability=ReliabilityPolicy.RELIABLE)
            self.create_subscription(OccupancyGrid, self.get_parameter('map_topic').value,
                                     self.map_callback, map_qos)
            self.get_logger().info('[START]   opponent reports:  %s' % topic)

        if self.get_parameter('aim_behind').value and not self.get_parameter('evade_on_capture').value:
            map_qos = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL,
                                 reliability=ReliabilityPolicy.RELIABLE)
            self.create_subscription(OccupancyGrid, self.get_parameter('map_topic').value,
                                     self.map_callback, map_qos)
        self.create_timer(1.0, self.tick)
        self.create_timer(0.1, self.unstick_step)
        self.get_logger().info('[START]   report topic:  %s   - tracker running' % self.report_pub.topic_name)

    def enemy_callback(self, msg):
        self.enemy_pose = msg
        self.last_pose_time = self.get_clock().now()

    def tick(self):
        if getattr(self, 'unstick_until', None) is not None:
            return   # backing out of a stuck spot
        if self.enemy_pose is None:
            self.get_logger().info('[WAIT]    waiting for enemy pose...', throttle_duration_sec=5.0)
            return
        age = (self.get_clock().now() - self.last_pose_time).nanoseconds / 1e9
        if age > 2.0:
            self.get_logger().warn('[WAIT]    enemy pose is %.1f s old - skipping' % age, throttle_duration_sec=5.0)
            return
        now = self.get_clock().now()
        if self.evade_until is not None:
            if now < self.evade_until:
                return          # still fleeing - don't chase yet
            self.evade_until = None
            self.last_goal = None   # forces a fresh chase goal below
            self.attack_side = None
            self.get_logger().info('[EVADE]   over - back to chasing')
        if self.locked:
            return          # lock-on is steering with cmd_vel - no Nav2 goals
        if self.get_parameter('aim_behind').value:
            goal = self.attack_goal()
        else:
            goal = self.standoff_goal()
        p = goal.pose.position
        moved = True
        if self.last_goal is not None:
            moved = math.hypot(p.x - self.last_goal[0], p.y - self.last_goal[1]) > self.get_parameter('goal_move_thresh').value
            waited = (now - self.last_goal_time).nanoseconds / 1e9 > 5.0
            moved = moved or waited
        if moved:
            self.send_goal(goal)
            self.last_goal = (p.x, p.y)
            self.last_goal_time = now

    def goal_result_callback(self, future):
        # Count Nav2 failures; after a few in a row we are probably wedged against something
        try:
            status = future.result().status
        except Exception:
            return
        if status == 6:   # ABORTED (planner could not find a path, recovery failed, ...)
            self.nav_fails = getattr(self, 'nav_fails', 0) + 1
            if self.nav_fails >= self.get_parameter('unstick_after_fails').value:
                self.nav_fails = 0
                self.start_unstick()
        elif status == 4:   # SUCCEEDED
            self.nav_fails = 0

    def start_unstick(self):
        # Turn on the spot to face the most open direction, then drive forwards out of the stuck spot
        if self.my_pose is None or getattr(self, 'unstick_until', None) is not None:
            return
        p = self.my_pose.pose.position
        best, best_score = None, -1
        for k in range(16):                                   # test 16 headings, 22.5 deg apart
            a = 2 * math.pi * k / 16
            score = sum(self.is_free(p.x + d * math.cos(a), p.y + d * math.sin(a), 0.15)
                        for d in (0.3, 0.45, 0.6))            # how far ahead stays free
            if score > best_score:
                best, best_score = a, score
        if self.goal_handle is not None:
            self.goal_handle.cancel_goal_async()
        self.unstick_heading = best
        self.unstick_phase = 'turn'
        self.unstick_until = self.get_clock().now() + Duration(seconds=6.0)   # safety time limit
        self.get_logger().warn('[STUCK]   Nav2 keeps failing - turning to %.0f deg, then driving forwards' % math.degrees(best))
    
    def unstick_step(self):
        if getattr(self, 'unstick_until', None) is None:
            return
        now = self.get_clock().now()
        if now > self.unstick_until:                          # give up and hand back to Nav2
            return self.finish_unstick()
        q = self.my_pose.pose.orientation
        yaw = math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))
        err = math.atan2(math.sin(self.unstick_heading - yaw), math.cos(self.unstick_heading - yaw))
        if self.unstick_phase == 'turn':
            if abs(err) > math.radians(10):
                self.publish_cmd(0.0, 0.8 if err > 0 else -0.8)   # spin in place
            else:
                self.unstick_phase = 'drive'
                self.unstick_drive_end = now + Duration(seconds=self.get_parameter('unstick_time').value)
        else:
            if now < self.unstick_drive_end:
                self.publish_cmd(0.12, 1.5 * err)            # forwards, small steering correction
            else:
                self.finish_unstick()

    def finish_unstick(self):
        self.publish_cmd(0.0, 0.0)
        self.unstick_until = None
        self.last_goal = None      # force a fresh Nav2 goal on the next tick
        self.get_logger().info('[STUCK]   clear - back to normal')

    def send_goal(self, pose, force=False):
        now = self.get_clock().now()
        last = getattr(self, 'last_send_time', None)
        if not force and last is not None and \
                (now - last).nanoseconds / 1e9 < self.get_parameter('min_goal_period').value:
            return   # too soon - let Nav2 finish what it is doing
        if not self.nav_client.server_is_ready():
            self.get_logger().warn('[NAV]     Nav2 not ready', throttle_duration_sec=5.0)
            return
        goal = NavigateToPose.Goal()
        goal.pose = pose
        goal.pose.header.frame_id = self.get_parameter('global_frame').value
        self.last_send_time = now
        future = self.nav_client.send_goal_async(goal)
        future.add_done_callback(self.goal_response_callback)
    
    def goal_response_callback(self, future):
        handle = future.result()
        if not handle.accepted:
            self.get_logger().warn('[NAV]     Nav2 rejected the goal')
            return
        if self.locked:
            handle.cancel_goal_async()   # we locked on while this goal was in flight
            return
        self.goal_handle = handle
        handle.get_result_async().add_done_callback(self.goal_result_callback)


    def my_callback(self, msg):
        self.my_pose = msg

    def standoff_goal(self):
        # Aim for a point standoff_dist short of the opponent, facing it.
        # The opponent itself is an obstacle in the costmap, so its centre is unreachable.
        goal = PoseStamped()
        goal.header.frame_id = self.get_parameter('global_frame').value
        goal.header.stamp = self.get_clock().now().to_msg()
        ex = self.enemy_pose.pose.position.x
        ey = self.enemy_pose.pose.position.y
        if self.my_pose is None:
            goal.pose = self.enemy_pose.pose
            return goal
        mx = self.my_pose.pose.position.x
        my = self.my_pose.pose.position.y
        dist = math.hypot(ex - mx, ey - my)
        standoff = self.get_parameter('standoff_dist').value
        if dist > standoff:
            k = (dist - standoff) / dist
            gx, gy = mx + k * (ex - mx), my + k * (ey - my)
        else:
            gx, gy = mx, my
        face = math.atan2(ey - gy, ex - gx)
        goal.pose.position.x, goal.pose.position.y = gx, gy
        goal.pose.orientation.z = math.sin(face / 2)
        goal.pose.orientation.w = math.cos(face / 2)
        return goal

    def pick_side(self, reason):
        open_sides = [k for k in ATTACK_SIDES if self.side_spot(k) is not None]
        self.attack_side = random.choice(open_sides or list(ATTACK_SIDES))
        self.side_time = self.get_clock().now()
        self.get_logger().info('[CHASE]   aiming for opponent\'s %s (%s)' % (self.attack_side, reason))

    def side_angle(self, side):
        # Split the capture arc into 3 equal slices (left, back, right) and aim at the
        # middle of one. For 220 deg: left/right = +/-106.7 deg, back = 180 deg from the nose.
        rear = min(self.get_parameter('rear_arc_deg').value, 360.0)
        edge = math.radians(180.0 - rear / 3.0)
        return {'back': math.pi, 'left': edge, 'right': -edge}[side]

    def side_spot(self, side):
        # Look for a free attack spot on one side of the opponent: try several distances and
        # small angle offsets inside that side's slice of the rear arc (20 tries, not just 1)
        if self.enemy_pose is None:
            return None
        opp = self.enemy_pose.pose
        q = opp.orientation
        opp_yaw = math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))
        d = self.get_parameter('standoff_dist').value
        clear = self.get_parameter('attack_clearance').value
        base = opp_yaw + self.side_angle(side)
        for dist in (d, d + 0.2, d + 0.4, d + 0.6):        # 0.5, 0.7, 0.9, 1.1 m by default (never closer than standoff_dist)
            for off in (0.0, 0.25, -0.25, 0.5, -0.5):     # radians; +/-0.5 stays inside the slice
                a = base + off
                gx = opp.position.x + dist * math.cos(a)
                gy = opp.position.y + dist * math.sin(a)
                if self.is_free(gx, gy, clear):
                    return gx, gy
        return None

    def attack_goal(self):
        # Go to a point standoff_dist from the opponent on the chosen side, facing it
        if self.my_pose is None:
            return self.standoff_goal()
        if self.attack_side is None:
            self.pick_side('new attack')
        elif (self.get_clock().now() - self.side_time).nanoseconds / 1e9 > self.get_parameter('side_reroll_time').value:
            self.pick_side('took too long, trying another side')
        opp = self.enemy_pose.pose
        q = opp.orientation
        opp_yaw = math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))
        d = self.get_parameter('standoff_dist').value
        order = [self.attack_side] + [k for k in ATTACK_SIDES if k != self.attack_side]
        for side in order:
            spot = self.side_spot(side)
            if spot is not None:
                gx, gy = spot
                if side != self.attack_side:
                    self.get_logger().info('[CHASE]   %s side blocked - switching to %s' % (self.attack_side, side))
                    self.attack_side = side
                break
        else:
            return self.standoff_goal()   # every side is blocked
        face = math.atan2(opp.position.y - gy, opp.position.x - gx)
        goal = PoseStamped()
        goal.header.frame_id = self.get_parameter('global_frame').value
        goal.header.stamp = self.get_clock().now().to_msg()
        goal.pose.position.x, goal.pose.position.y = gx, gy
        goal.pose.orientation.z = math.sin(face / 2)
        goal.pose.orientation.w = math.cos(face / 2)
        return goal

    def pose_from_tf(self, robot):
        frame = robot + '/' + self.get_parameter('base_frame').value
        try:
            t = self.tf_buffer.lookup_transform(self.get_parameter('global_frame').value, frame, Time())
        except Exception:
            return None
        ps = PoseStamped()
        ps.header.frame_id = self.get_parameter('global_frame').value
        ps.header.stamp = self.get_clock().now().to_msg()
        ps.pose.position.x = t.transform.translation.x
        ps.pose.position.y = t.transform.translation.y
        ps.pose.orientation = t.transform.rotation
        return ps

    def update_poses_from_tf(self):
        me = self.pose_from_tf(self.get_parameter('chaser').value)
        opp = self.pose_from_tf(self.get_parameter('enemy').value)
        if me is not None:
            self.my_pose = me
        if opp is not None:
            self.enemy_callback(opp)

    def image_callback(self, msg):
        self.latest_image = msg

    def relative_to_opponent(self):
        me = self.my_pose.pose
        opp = self.enemy_pose.pose
        dx = opp.position.x - me.position.x
        dy = opp.position.y - me.position.y
        q = me.orientation
        yaw = math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))
        bearing = math.atan2(dy, dx) - yaw
        bearing = math.atan2(math.sin(bearing), math.cos(bearing))
        return math.hypot(dx, dy), bearing

    def map_callback(self, msg):
        self.map = msg

    def is_free(self, x, y, clearance=0.3):
        # True if every map cell within clearance of (x, y) is known-free
        if self.map is None:
            return True
        info = self.map.info
        r = info.resolution
        cx = int((x - info.origin.position.x) / r)
        cy = int((y - info.origin.position.y) / r)
        n = int(clearance / r)
        for j in range(cy - n, cy + n + 1):
            for i in range(cx - n, cx + n + 1):
                if i < 0 or j < 0 or i >= info.width or j >= info.height:
                    return False
                if not (0 <= self.map.data[j * info.width + i] < 50):
                    return False
        return True

    def opp_report_callback(self, msg):
        # The opponent published a capture report - is it about us?
        if msg.opp_id != self.get_parameter('my_id').value:
            return
        # Game rule: only the capturer has to run off. The captured robot may capture back at once.
        self.last_capture_time = None   # clear OUR cooldown - we can capture again immediately
        self.attack_side = None         # pick a fresh side for the counter-attack
        self.last_goal = None           # send a new chase goal on the next tick
        if self.get_parameter('evade_when_captured').value:
            if self.evade_until is None and self.my_pose is not None and self.enemy_pose is not None:
                self.start_evade()
            return
        self.get_logger().info('[HIT]     captured by opponent - counter-attacking now (cooldown cleared)')

    def random_flee_point(self, me, opp):
        # Random free spot the robot can actually drive to (flood fill from where we are),
        # far enough from the opponent and from ourselves
        if self.map is None:
            return None
        info = self.map.info
        r, W, H = info.resolution, info.width, info.height
        ox, oy = info.origin.position.x, info.origin.position.y
        sx, sy = int((me.x - ox) / r), int((me.y - oy) / r)
        data = self.map.data
        seen = bytearray(W * H)
        queue = collections.deque()
        # Seed the flood fill with free cells near us (our own cell can read as occupied/unknown)
        n = int(0.5 / r)
        for cy in range(sy - n, sy + n + 1):
            for cx in range(sx - n, sx + n + 1):
                if 0 <= cx < W and 0 <= cy < H and data[cy * W + cx] == 0:
                    seen[cy * W + cx] = 1
                    queue.append((cx, cy))
        if not queue:
            return None
        cells = []
        while queue:
            cx, cy = queue.popleft()
            cells.append((cx, cy))
            for nx, ny in ((cx + 1, cy), (cx - 1, cy), (cx, cy + 1), (cx, cy - 1)):
                k = ny * W + nx
                if 0 <= nx < W and 0 <= ny < H and not seen[k] and data[k] == 0:
                    seen[k] = 1
                    queue.append((nx, ny))
        min_opp = self.get_parameter('evade_min_opp_dist').value
        random.shuffle(cells)
        for cx, cy in cells[:4000]:
            gx, gy = ox + (cx + 0.5) * r, oy + (cy + 0.5) * r
            if math.hypot(gx - opp.x, gy - opp.y) < min_opp or math.hypot(gx - me.x, gy - me.y) < 1.0:
                continue
            if not self.is_free(gx, gy, clearance=0.35):
                continue
            return (0.0, gx, gy, math.atan2(gy - me.y, gx - me.x))
        return None

    def start_evade(self, why='captured by opponent'):
        self.unlock('we were captured')
        self.in_view_since = None
        me = self.my_pose.pose.position
        opp = self.enemy_pose.pose.position
        best = self.random_flee_point(me, opp)
        wait = self.get_parameter('evade_time').value or (self.get_parameter('capture_cooldown').value + 1.5)
        self.evade_until = self.get_clock().now() + Duration(seconds=wait)
        if best is None:
            self.get_logger().warn('[EVADE]   no free spot to flee to - holding position')
            return
        _, gx, gy, a = best
        goal = PoseStamped()
        goal.header.frame_id = self.get_parameter('global_frame').value
        goal.header.stamp = self.get_clock().now().to_msg()
        goal.pose.position.x, goal.pose.position.y = gx, gy
        goal.pose.orientation.z = math.sin(a / 2)
        goal.pose.orientation.w = math.cos(a / 2)
        self.send_goal(goal, force=True)
        self.get_logger().info('[EVADE]   %s - fleeing to (%.2f, %.2f) for %.1f s' % (why, gx, gy, wait))

    def lock_on(self):
        if not self.get_parameter('lock_on').value or self.locked:
            return
        self.locked = True
        if self.goal_handle is not None:
            self.goal_handle.cancel_goal_async()   # stop Nav2 so it does not fight our cmd_vel
        self.get_logger().info('[LOCK]    locked on - steering straight at opponent')

    def unlock(self, reason):
        if not self.locked:
            return
        self.locked = False
        self.publish_cmd(0.0, 0.0)   # stop
        self.last_goal = None           # let tick() send a fresh Nav2 goal straight away
        self.get_logger().info('[LOCK]    released (%s)' % reason)

    def publish_cmd(self, v, w):
        if self.get_parameter('cmd_vel_stamped').value:
            msg = TwistStamped()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = self.get_parameter('chaser').value + '/' + self.get_parameter('base_frame').value
            msg.twist.linear.x = float(v)
            msg.twist.angular.z = float(w)
        else:
            msg = Twist()
            msg.linear.x = float(v)
            msg.angular.z = float(w)
        self.cmd_pub.publish(msg)

    def lock_control(self):
        if getattr(self, 'unstick_until', None) is not None:
            return
        # P-controller: turn to keep the opponent centred, drive to hold lock_dist behind it
        if not self.locked or self.my_pose is None or self.enemy_pose is None:
            return
        dist, bearing = self.relative_to_opponent()
        w_max = self.get_parameter('lock_max_ang').value
        v_max = self.get_parameter('lock_max_lin').value
        w = max(-w_max, min(w_max, 2.0 * bearing))
        v = 0.8 * (dist - self.get_parameter('lock_dist').value)
        v *= max(0.0, math.cos(bearing))   # slow down while turning
        self.publish_cmd(max(-0.1, min(v_max, v)), w)

    def lost_view(self):
        # Opponent left the zone - reset the hold timer unless it was only a brief drop-out
        if self.in_view_since is None:
            return
        t = self.get_clock().now()
        if (t - self.last_in_view).nanoseconds / 1e9 < self.get_parameter('hold_grace_time').value:
            return
        held = (self.last_in_view - self.in_view_since).nanoseconds / 1e9
        self.get_logger().info('[LOCK]    lost opponent after %.1f s' % held)
        self.in_view_since = None
        self.unlock('lost opponent')

    def why_no_capture(self, reason):
        # Say why check_capture() stopped early (at most once every 2 s so it does not flood)
        self.get_logger().info('[WAIT]    no capture: ' + reason, throttle_duration_sec=2.0)

    def check_capture(self):
        if self.evade_until is not None:
            self.why_no_capture('evading (running away)')
            return   # running away - no captures until the evade is over
        if self.my_pose is None or self.enemy_pose is None:
            self.why_no_capture('missing pose - mine: %s, enemy: %s' % (
                'ok' if self.my_pose is not None else 'NONE', 'ok' if self.enemy_pose is not None else 'NONE'))
            return
        if self.latest_image is None and self.get_parameter('require_image').value:
            self.why_no_capture('no camera frame received yet (check camera_topic, or use require_image:=false)')
            return
        dist, bearing = self.relative_to_opponent()
        in_zone = (dist <= self.get_parameter('zone_max_dist').value and
                   abs(math.degrees(bearing)) <= self.get_parameter('zone_half_fov_deg').value)
        if not in_zone:
            self.why_no_capture('opponent not in view zone: %.2f m (need <= %.2f), %.0f deg (need within +/-%.0f)' % (
                dist, self.get_parameter('zone_max_dist').value, math.degrees(bearing),
                self.get_parameter('zone_half_fov_deg').value))
            self.lost_view()
            return
        # Capture-arc rule: with capture_arc_deg < 360 we must be outside the opponent's front
        # (360 - capture_arc_deg) wedge. At 360 (default) a capture counts from any angle, even the front.
        # Targeting (side_angle) still uses rear_arc_deg, so we still AIM for back/left/right.
        rear = self.get_parameter('capture_arc_deg').value
        if rear < 360.0:
            me = self.my_pose.pose.position
            opp = self.enemy_pose.pose
            q = opp.orientation
            opp_yaw = math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))
            a = math.atan2(me.y - opp.position.y, me.x - opp.position.x) - opp_yaw
            a = math.atan2(math.sin(a), math.cos(a))
            if abs(math.degrees(a)) < (360.0 - rear) / 2.0:
                self.why_no_capture('in front of the opponent (capture_arc_deg = %.0f)' % rear)
                self.lost_view()
                return   # we are in front of the opponent - not a valid capture
            self.last_nose_angle = abs(math.degrees(a))
        # Hold rule: start (or continue) the timer while the opponent is in the zone
        t = self.get_clock().now()
        self.last_in_view = t
        if self.in_view_since is None:
            self.in_view_since = t
            if self.get_parameter('capture_hold_time').value > 0:
                self.get_logger().info('[CAPTURE] opponent in view - holding for %.1f s'
                                       % self.get_parameter('capture_hold_time').value)
            self.lock_on()
        if (t - self.in_view_since).nanoseconds / 1e9 < self.get_parameter('capture_hold_time').value:
            self.why_no_capture('holding opponent in view')
            return
        # Shooting range: lock-on keeps closing in until we are within capture_dist
        if dist > self.get_parameter('capture_dist').value:
            self.why_no_capture('locked on, closing in: %.2f m (need <= %.2f)' % (
                dist, self.get_parameter('capture_dist').value))
            return
        now = self.get_clock().now()
        if self.last_capture_time is not None:
            if (now - self.last_capture_time).nanoseconds / 1e9 < self.get_parameter('capture_cooldown').value:
                self.why_no_capture('cooldown after last capture')
                return
        try:
            # Fill the report field by field. The image fields are copied straight from the
            # CompressedImage that image_callback stored - header, format and data unchanged.
            report = TrackerReport()
            report.header.stamp = self.get_clock().now().to_msg()
            report.header.frame_id = str(self.get_parameter('global_frame').value)
            if self.latest_image is not None:
                report.image.header = self.latest_image.header
                report.image.format = self.latest_image.format
                report.image.data = self.latest_image.data
            report.my_id = int(self.get_parameter('my_id').value) & 0xFF     # uint8
            report.opp_id = int(self.get_parameter('opp_id').value) & 0xFF   # uint8
            report.rel_dist = float(dist)                                    # float32, metres
            report.rel_orient = float(bearing)                               # float32, radians
            image = report.image
            self.report_pub.publish(report)
            self.report_img_pub.publish(image)   # separate copy so RViz can show it
        except Exception as e:
            self.get_logger().error('[ERROR]   capture report NOT sent - %s: %s' % (type(e).__name__, e))
            return
        self.last_capture_time = now
        self.capture_count += 1
        self.attack_side = None   # pick a new side for the next attack
        self.in_view_since = None  # the next capture needs a fresh hold
        self.unlock('capture made')
        save_dir = self.get_parameter('save_dir').value
        if save_dir and image.data:
            os.makedirs(save_dir, exist_ok=True)
            with open(os.path.join(save_dir, 'capture_%03d.jpg' % self.capture_count), 'wb') as f:
                f.write(image.data)
        img = ('%.1f kB, format "%s"' % (len(image.data) / 1024.0, image.format)) if image.data else 'none'
        self.get_logger().info(
            '[CAPTURE] #%d  report sent on %s\n'
            '          opponent: %.2f m at %+.0f deg   ids: us %d -> opp %d   image: %s'
            % (self.capture_count, self.report_pub.topic_name, dist, math.degrees(bearing),
               report.my_id, report.opp_id, img))
        if self.get_parameter('evade_after_capture').value:
            self.start_evade('captured opponent')


def main():
    rclpy.init()
    node = TrackerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()