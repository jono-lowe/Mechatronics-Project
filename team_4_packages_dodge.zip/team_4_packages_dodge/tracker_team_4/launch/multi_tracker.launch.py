# Runs the same tracker_node on both simulated TurtleBot3s (Unit 6 multi-robot sim):
# tb3_0 hunts tb3_1 and tb3_1 hunts tb3_0. Start path_planner_server multi_main.launch.xml first.
from launch import LaunchDescription
from launch_ros.actions import Node


def tracker(me, opp, my_id, opp_id):
    return Node(
        package='tracker_team_4',
        executable='tracker_node',
        name='tracker_node',
        namespace=me,
        output='screen',
        parameters=[{
            'use_sim_time': True,
            'chaser': me,
            'enemy': opp,
            'my_id': my_id,
            'opp_id': opp_id,
            'use_tf_poses': True,
            'evade_on_capture': True,
            'capture_cooldown': 5.0,
            'standoff_dist': 0.3,
            'base_frame': 'base_footprint',
            'camera_compressed': False,
            'cmd_vel_stamped': False,
            'require_image': False,   # TB3 burgers have no camera; reports go out with an empty image
        }],
    )


def generate_launch_description():
    return LaunchDescription([
        tracker('tb3_0', 'tb3_1', 0, 1),
        tracker('tb3_1', 'tb3_0', 1, 0),
    ])
