# Simulation test: two copies of the tracker chasing each other (tb3_0 vs tb3_1).
# Differences from the real-robot launch: sim clock, and no camera image required
# (the sim TurtleBot3s have no OAK-D, so captures would never fire otherwise).
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def tracker(chaser, enemy):
    return Node(
        package='tracker_team_4',
        executable='tracker_node',
        name='tracker_' + chaser,
        output='screen',
        parameters=[{
            'chaser': chaser,
            'enemy': enemy,
            'global_frame': 'map',
            'use_tf_poses': True,
            'use_sim_time': True,
            'require_image': False,
            'evade_on_capture': True,
            'evade_after_capture': LaunchConfiguration('evade_after_capture'),
        }],
    )


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('robot_a', default_value='tb3_0'),
        DeclareLaunchArgument('robot_b', default_value='tb3_1'),
        DeclareLaunchArgument('evade_after_capture', default_value='true'),
        tracker('tb3_0', 'tb3_1'),
        tracker('tb3_1', 'tb3_0'),
    ])
